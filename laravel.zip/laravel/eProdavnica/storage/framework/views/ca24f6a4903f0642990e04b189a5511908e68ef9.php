
<?php $__env->startSection("content"); ?>

<div class=" custom-product">
<div class="col-sm-10">
<div class="trending-wrapper">
<h4>Moje porudzbine</h4>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row searched-item cart-list-devider">
<div class="col-sm-3">

<a href="detail/<?php echo e($item->id); ?>">
      <img class="trending-image" src="<?php echo e($item->gallery); ?>" >
      </a>

</div>
<div class="col-sm-4">

<a href="detail/<?php echo e($item->id); ?>">
      
      <div class="">
        <h2> Ime: <?php echo e($item->name); ?></h2>
        <h5>Status isporuke: <?php echo e($item->status); ?></h5>
        <h5>Adresa: <?php echo e($item->address); ?></h5>
        <h5>Status naplate: <?php echo e($item->payment_status); ?></h5>
        <h5>Nacin nplacanja: <?php echo e($item->payment_method); ?></h5>
        
        
      </div>
      </a>

</div>
<div class="col-sm-3">

<a href="detail/<?php echo e($item->id); ?>">
    
      <div class="">
        <h2><?php echo e($item->price); ?> din</h2>
      </div>
      </a>

</div>

    </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andje\OneDrive\Dokumenti\laravel\eProdavnica\resources\views/myorders.blade.php ENDPATH**/ ?>