<footer class="footer" id="footer">
  <div class="container"><br>
    <div class="row">
      <div class="col-sm-12 text-center">
        <div class="social-icon">
        <br><br><br>
          <a href="#"><i class="fa fa-facebook"></i></a>
          <a href="#"><i class="fa fa-twitter"></i></a>
          <a href="#"><i class="fa fa-pinterest"></i></a>
          <a href="#"><i class="fa fa-rss"></i></a>
        </div>
        <div class="copyright">
          <p class="white"> copyright &copy; <b>GOD</b></p>
          <p><i class="fa fa-phone"></i> +381 (11) 2337 890&nbsp;<br><i class="fa fa-envelope-o"></i> informacije@god.com
          </p>
        </div>
      </div>
    </div>
  </div>
</footer><?php /**PATH C:\Users\andje\OneDrive\Dokumenti\laravel\eProdavnica\resources\views/footer.blade.php ENDPATH**/ ?>