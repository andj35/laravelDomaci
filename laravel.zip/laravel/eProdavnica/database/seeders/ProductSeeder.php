<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        DB::table('products')->insert([
         [ 'name'=>'vrata N1245',
            "price"=>'14000',
            "description"=>'drvena vrata',
            "category"=>"vrata",
            "gallery"=>"https://samigoinvest.rs/wp-content/uploads/2020/11/sobna-vrata-V-5-hrast.jpg",


            


        ],
        [
            'name'=>'prozor N1285',
            "price"=>'12000',
            "description"=>'tamno braon',
            "category"=>"prozor",
            "gallery"=>"https://vagres.rs/wp-content/uploads/2018/08/01.png",


            


        ],
        [
            'name'=>'polica N7245',
            "price"=>'5500',
            "description"=>'kosa svetla',
            "category"=>"polica",
            "gallery"=>"https://www.ena.rs/images/products/2412/big/ena2018-20190510162936.jpg",


            


        ],
        [
            'name'=>'polica N5845',
            "price"=>'7000',
            "description"=>'bas svetla',
            "category"=>"polica",
            "gallery"=>"https://pevex.hr/media/catalog/product/cache/d46e7ff9bf21dac5393cb76c239f1f61/2/5/257210-1.jpg",


            


        ],
        [
            'name'=>'vrata N9246',
            "price"=>'16000',
            "description"=>'tamno braon',
            "category"=>"vrata",
            "gallery"=>"https://drvotrade.co.rs/images/proizvodi/vrata/sobna/sobna_vrata_25.jpg",


            


        ],
        [
            'name'=>'vrata N70246',
            "price"=>'19000',
            "description"=>'bela',
            "category"=>"vrata",
            "gallery"=>"https://www.jonimpex.rs/wp-content/uploads/2017/04/Sobna-vrata-Bela-lak.jpg",


            


        ],
        [
            'name'=>'vrata N4246',
            "price"=>'24000',
            "description"=>'drvena',
            "category"=>"vrata",
            "gallery"=>"https://www.kucastolarije.com/wp-content/uploads/ulazna-drvena-vrata-9.jpg",


            


        ]
         ] );
    }
}
