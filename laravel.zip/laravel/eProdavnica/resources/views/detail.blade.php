@extends('master')
@section("content")

<div class="container">

<div class="row">
<div class="col-sm-6">
  <img class="detail-img" src="{{$product['gallery']}}">
</div>
<div class="col-sm-6">
<a href="/">Nazad</a>
<h2>{{$product['name']}}</h2>
<h2>Cena: {{$product['price']}} din</h2>
<h2>Detalji: {{$product['description']}}</h2>
<h2>Kategorija: {{$product['category']}}</h2>
<br><br>

<form action="/add_to_cart" method="POST">
@csrf
<input type="hidden" name="product_id" value={{$product['id']}}>
<button class="btn btn-primary">Dodaj u korpu</button>
</form>
<br><br>



</div>
</div>


</div>

@endsection