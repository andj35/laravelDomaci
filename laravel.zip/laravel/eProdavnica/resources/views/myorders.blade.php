@extends('master')
@section("content")

<div class=" custom-product">
<div class="col-sm-10">
<div class="trending-wrapper">
<h4>Moje porudzbine</h4>
@foreach ($orders as $item)
<div class="row searched-item cart-list-devider">
<div class="col-sm-3">

<a href="detail/{{$item->id}}">
      <img class="trending-image" src="{{$item->gallery}}" >
      </a>

</div>
<div class="col-sm-4">

<a href="detail/{{$item->id}}">
      
      <div class="">
        <h2> Ime: {{$item->name}}</h2>
        <h5>Status isporuke: {{$item->status}}</h5>
        <h5>Adresa: {{$item->address}}</h5>
        <h5>Status naplate: {{$item->payment_status}}</h5>
        <h5>Nacin nplacanja: {{$item->payment_method}}</h5>
        
        
      </div>
      </a>

</div>
<div class="col-sm-3">

<a href="detail/{{$item->id}}">
    
      <div class="">
        <h2>{{$item->price}} din</h2>
      </div>
      </a>

</div>

    </div>
 @endforeach
  </div>

</div>

</div>

@endsection